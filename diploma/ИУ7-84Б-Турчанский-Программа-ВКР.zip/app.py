from flask import Flask, render_template, request, send_file, flash
import os
from werkzeug.utils import secure_filename
from pathlib import Path
import pandas as pd
from multiprocessing import freeze_support
import datetime

from src.describer import Describer
from src.generator import Generator

app = Flask(__name__)
app.secret_key = 'your-secret-key'  # needed for flash messages

# Configure upload folder
UPLOAD_FOLDER = 'uploads'
OUTPUT_FOLDER = 'output'
ALLOWED_EXTENSIONS = {'csv'}

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['OUTPUT_FOLDER'] = OUTPUT_FOLDER

# Create directories if they don't exist
Path(UPLOAD_FOLDER).mkdir(exist_ok=True)
Path(OUTPUT_FOLDER).mkdir(exist_ok=True)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        # Check if file was uploaded
        if 'file' not in request.files:
            flash('No file selected')
            return render_template('index.html')
        
        file = request.files['file']
        if file.filename == '':
            flash('No file selected')
            return render_template('index.html')
        
        if file and allowed_file(file.filename):
            # Save uploaded file
            filename = secure_filename(file.filename)
            input_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(input_path)
            
            # Get parameters from form
            threshold_value = int(request.form.get('threshold', 20))
            epsilon = float(request.form.get('epsilon', 1))
            degree_of_bayesian_network = int(request.form.get('degree', 2))
            num_tuples = int(request.form.get('num_tuples', 10000))
            generation_mode = request.form.get('mode', 'correlated')
            
            try:
                # Setup paths
                description_file = os.path.join(app.config['OUTPUT_FOLDER'], 'description.json')
                output_data = os.path.join(app.config['OUTPUT_FOLDER'], f'synthetic_data_{datetime.datetime.now()}.csv')
                
                # Generate synthetic data
                describer = Describer(category_threshold=threshold_value)
                describer.describe_dataset_in_correlated_attribute_mode(
                    dataset_file=input_path,
                    epsilon=epsilon,
                    k=degree_of_bayesian_network
                )
                
                describer.save_dataset_description_to_file(description_file)
                
                generator = Generator()
                
                generator.generate_dataset_in_correlated_attribute_mode(
                    num_tuples, 
                    description_file
                )

                    
                generator.save_synthetic_data(output_data)
                
                # Return the generated file
                return send_file(
                    output_data,
                    mimetype='text/csv',
                    as_attachment=True,
                    download_name='synthetic_data.csv'
                )
                
            except Exception as e:
                flash(f'Error processing file: {str(e)}')
                return render_template('index.html')
    
    return render_template('index.html')

if __name__ == '__main__':
    freeze_support()
    app.run(debug=True)